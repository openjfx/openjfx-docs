package hellofx;

public class Launcher {
    
    public static void main(String[] args) {
        HelloFX.main(args);
    }
}
